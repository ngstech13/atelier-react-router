# Atelier : mettre en place la navigation (React Router v7 + React 19)

## Lancer le projet

```bash
npm install
npm run dev
```

Ouvrir http://localhost:5173

## Routes

| URL | Page | Remarque |
|---|---|---|
| `/` | Home | route index du Layout |
| `/about` | About | |
| `/products` | ProductList | filtre `?categorie=accessoires` |
| `/products/:id` | ProductDetail | paramètre d'URL, bouton Retour |
| `/login` | Login | `?redirect=/dashboard` |
| `/dashboard` | Dashboard | protégée par un loader |
| `*` | NotFound | page 404 |

## Concepts illustrés

- `createBrowserRouter` + `RouterProvider` (`react-router/dom`)
- Routes imbriquées, `Layout` et `Outlet`
- `Link`, `NavLink` (classe `actif`), `useNavigate`
- `useParams`, `useSearchParams`
- Redirections : `<Navigate replace />`, `navigate()`, `redirect()` dans un loader
- `errorElement` avec `useRouteError`

## Critères de réussite

1. La navigation ne recharge pas la page.
2. Le lien actif est mis en évidence.
3. Une URL inconnue affiche la 404.
4. `/products/2` affiche le bon produit.
5. `/dashboard` sans connexion redirige vers `/login`, puis revient sur `/dashboard` après connexion.

## Pour aller plus loin

- Charger les produits avec un `loader` et `useLoaderData`
- Ajouter une `action` et `<Form>` pour la connexion
