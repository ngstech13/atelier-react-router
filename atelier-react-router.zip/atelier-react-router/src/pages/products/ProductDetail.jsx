import { Link, useNavigate, useParams } from "react-router";
import { products } from "../../data/products";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find((p) => p.id === Number(id));

  if (!product) {
    return (
      <>
        <h1>Produit introuvable</h1>
        <p>Aucun produit ne porte le numéro {id}.</p>
        <Link to="/products">Retour à la liste</Link>
      </>
    );
  }

  return (
    <>
      <h1>{product.name}</h1>
      <p>Produit n° {product.id}</p>
      <p>Catégorie : {product.categorie}</p>
      <p>Prix : {product.prix} DT</p>
      <button onClick={() => navigate(-1)}>Retour</button>
    </>
  );
}
