import { Link, useSearchParams } from "react-router";
import { products, categories } from "../../data/products";

export default function ProductList() {
  const [searchParams, setSearchParams] = useSearchParams();
  const categorie = searchParams.get("categorie");

  const filtered = categorie
    ? products.filter((p) => p.categorie === categorie)
    : products;

  return (
    <>
      <h1>Produits</h1>

      <div className="filtres">
        <button onClick={() => setSearchParams({})} disabled={!categorie}>
          Tous
        </button>
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setSearchParams({ categorie: c })}
            disabled={categorie === c}
          >
            {c}
          </button>
        ))}
      </div>

      <ul className="liste">
        {filtered.map((p) => (
          <li key={p.id}>
            <Link to={`/products/${p.id}`}>{p.name}</Link>
            <span className="prix">{p.prix} DT</span>
          </li>
        ))}
      </ul>
    </>
  );
}
