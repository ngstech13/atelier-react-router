export default function About() {
  return (
    <>
      <h1>À propos</h1>
      <p>Cette application illustre le routage côté client : routes imbriquées, paramètres, redirections et routes protégées.</p>
    </>
  );
}
