import { Link } from "react-router";

export default function Home() {
  return (
    <>
      <h1>Accueil</h1>
      <p>Bienvenue dans l'atelier de navigation avec React Router v7 et React 19.</p>
      <p>
        <Link to="/products">Voir les produits</Link>
      </p>
    </>
  );
}
