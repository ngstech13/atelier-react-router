import { Link } from "react-router";

export default function NotFound() {
  return (
    <>
      <h1>404 : page introuvable</h1>
      <p>L'adresse demandée n'existe pas.</p>
      <Link to="/">Retour à l'accueil</Link>
    </>
  );
}
