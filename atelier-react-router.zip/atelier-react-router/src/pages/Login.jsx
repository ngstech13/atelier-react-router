import { useState } from "react";
import { Navigate, useNavigate, useSearchParams } from "react-router";
import { isLoggedIn, login } from "../auth/auth";

export default function Login() {
  const [username, setUsername] = useState("");
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Page visée avant la redirection (par défaut : tableau de bord)
  const redirectTo = searchParams.get("redirect") || "/dashboard";

  // Déjà connecté : redirection déclarative
  if (isLoggedIn()) {
    return <Navigate to={redirectTo} replace />;
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!username.trim()) return;
    login(username.trim());
    navigate(redirectTo, { replace: true });
  }

  return (
    <>
      <h1>Connexion</h1>
      {searchParams.get("redirect") && (
        <p className="info">Connectez-vous pour accéder à {redirectTo}.</p>
      )}
      <form onSubmit={handleSubmit} className="form">
        <label>
          Nom d'utilisateur
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="ex. aymen"
            autoFocus
          />
        </label>
        <button type="submit">Se connecter</button>
      </form>
    </>
  );
}
