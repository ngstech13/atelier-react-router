import { Link, isRouteErrorResponse, useRouteError } from "react-router";

export default function ErrorPage() {
  const error = useRouteError();
  const message = isRouteErrorResponse(error)
    ? `${error.status} ${error.statusText}`
    : error?.message ?? "Erreur inconnue";

  return (
    <div className="main">
      <h1>Une erreur est survenue</h1>
      <p>{message}</p>
      <Link to="/">Retour à l'accueil</Link>
    </div>
  );
}
