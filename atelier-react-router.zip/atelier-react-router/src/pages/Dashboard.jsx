import { getUser } from "../auth/auth";

export default function Dashboard() {
  return (
    <>
      <h1>Tableau de bord</h1>
      <p>Bonjour {getUser()}, cette page est réservée aux utilisateurs connectés.</p>
    </>
  );
}
