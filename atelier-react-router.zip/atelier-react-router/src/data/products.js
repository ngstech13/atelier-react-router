export const products = [
  { id: 1, name: "Clavier", categorie: "accessoires", prix: 45 },
  { id: 2, name: "Écran", categorie: "ecrans", prix: 220 },
  { id: 3, name: "Souris", categorie: "accessoires", prix: 25 },
  { id: 4, name: "Écran incurvé", categorie: "ecrans", prix: 340 },
];

export const categories = ["accessoires", "ecrans"];
