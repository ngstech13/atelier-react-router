import { redirect } from "react-router";

// Authentification simulée (atelier uniquement, pas de sécurité réelle)
const KEY = "atelier-user";

export function isLoggedIn() {
  return localStorage.getItem(KEY) !== null;
}

export function getUser() {
  return localStorage.getItem(KEY);
}

export function login(username) {
  localStorage.setItem(KEY, username);
}

export function logout() {
  localStorage.removeItem(KEY);
}

// Loader : s'exécute AVANT le rendu de la route
export function protectedLoader({ request }) {
  if (!isLoggedIn()) {
    const url = new URL(request.url);
    return redirect(`/login?redirect=${encodeURIComponent(url.pathname)}`);
  }
  return null;
}
