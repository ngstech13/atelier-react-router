import { createBrowserRouter } from "react-router";
import Layout from "./layouts/Layout";
import Home from "./pages/Home";
import About from "./pages/About";
import ProductList from "./pages/products/ProductList";
import ProductDetail from "./pages/products/ProductDetail";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import ErrorPage from "./pages/ErrorPage";
import { protectedLoader } from "./auth/auth";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    errorElement: <ErrorPage />,
    children: [
      { index: true, element: <Home /> },
      { path: "about", element: <About /> },
      {
        path: "products",
        children: [
          { index: true, element: <ProductList /> },
          { path: ":id", element: <ProductDetail /> },
        ],
      },
      { path: "login", element: <Login /> },
      // Route protégée : le loader redirige vers /login si non connecté
      { path: "dashboard", element: <Dashboard />, loader: protectedLoader },
      { path: "*", element: <NotFound /> },
    ],
  },
]);
