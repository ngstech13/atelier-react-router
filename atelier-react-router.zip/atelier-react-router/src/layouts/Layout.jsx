import { NavLink, Outlet, useLocation, useNavigate } from "react-router";
import { isLoggedIn, logout } from "../auth/auth";

export default function Layout() {
  const navigate = useNavigate();
  useLocation(); // force le rafraîchissement du menu à chaque navigation

  const linkClass = ({ isActive }) => (isActive ? "nav-link actif" : "nav-link");

  function handleLogout() {
    logout();
    navigate("/");
  }

  return (
    <>
      <header className="header">
        <span className="logo">Atelier Router</span>
        <nav className="nav">
          <NavLink to="/" end className={linkClass}>Accueil</NavLink>
          <NavLink to="/products" className={linkClass}>Produits</NavLink>
          <NavLink to="/about" className={linkClass}>À propos</NavLink>
          {isLoggedIn() && (
            <NavLink to="/dashboard" className={linkClass}>Tableau de bord</NavLink>
          )}
        </nav>
        {isLoggedIn() ? (
          <button onClick={handleLogout}>Se déconnecter</button>
        ) : (
          <NavLink to="/login" className={linkClass}>Se connecter</NavLink>
        )}
      </header>
      <main className="main">
        <Outlet />
      </main>
    </>
  );
}
